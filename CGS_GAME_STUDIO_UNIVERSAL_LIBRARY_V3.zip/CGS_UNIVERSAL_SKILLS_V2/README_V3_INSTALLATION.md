# CGS GAME STUDIO — Universal Skills V3

- **31 domaines**
- **10 Skills spécialisés par domaine**
- **310 Skills au total**
- **1 Skill maître importable dans Claude** : `CGS_GAME_STUDIO_UNIVERSAL_SKILL_INSTALLER.zip`

## Installation unique
Dans Claude Web, ouvrir Customize → Skills → Upload skill, puis sélectionner l'archive `CGS_GAME_STUDIO_UNIVERSAL_SKILL_INSTALLER.zip`. Si Claude affiche une erreur de validation ou de taille, consulter les limites d'import de la version actuelle de Claude. Le pack contient un seul `SKILL.md` racine qui route vers les 310 playbooks rangés dans `knowledge/`.

## Utilisation
Le Skill maître doit lire uniquement 1 à 4 playbooks pertinents par tâche. Il ne doit jamais charger les 310 à chaque requête : cela gaspillerait le contexte et les tokens.

## Domaines
- 1. Direction & Production: 10 Skills
- 2. Game Design & Systems: 10 Skills
- 3. Software Architecture & Programming: 10 Skills
- 4. Godot Engine: 10 Skills
- 5. Unity Engine: 10 Skills
- 6. Unreal Engine: 10 Skills
- 7. 2D Art & Animation Assets: 10 Skills
- 8. 3D Art & Environments: 10 Skills
- 9. Animation & Rigging: 10 Skills
- 10. Game AI & NPC Systems: 10 Skills
- 11. Physics & Simulation: 10 Skills
- 12. Gameplay, Controls & Camera: 10 Skills
- 13. Multiplayer & Networking: 10 Skills
- 14. Narrative & Worldbuilding: 10 Skills
- 15. Audio & Music: 10 Skills
- 16. UI/UX & Interface: 10 Skills
- 17. Performance & Cross-platform: 10 Skills
- 18. QA, Testing & Debugging: 10 Skills
- 19. Git & Collaboration: 10 Skills
- 20. Build, Publishing & Maintenance: 10 Skills
- 21. Level Design & World Building: 10 Skills
- 22. Combat & Action Systems: 10 Skills
- 23. Vehicles & Racing Games: 10 Skills
- 24. Sports Games & Simulation: 10 Skills
- 25. RPG, Inventory & Progression: 10 Skills
- 26. Procedural Generation & Tools: 10 Skills
- 27. DCC Tools & Production Automation: 10 Skills
- 28. Backend, Cloud & Services: 10 Skills
- 29. Monetization & Live Operations: 10 Skills
- 30. Accessibility & Localization: 10 Skills
- 31. Security, Privacy & Trust: 10 Skills