# CGS GAME STUDIO — Universal Skills Library v2

**31 domaines · 5 Skills par domaine · 155 Skills au total**

Cette bibliothèque est modulaire. Chaque dossier de Skill contient un `SKILL.md` autonome. Importer seulement les Skills utiles à chaque projet pour limiter le contexte et les tokens.

## Structure des domaines
1. **Direction & Production** — 5 Skills
   - `vision_product_owner` — Vision & Product Owner
   - `production_roadmap` — Roadmap & Production Planning
   - `scope_risk_management` — Scope & Risk Management
   - `team_workflow` — Team Workflow & Collaboration
   - `project_audit` — Project Audit & Technical Due Diligence
2. **Game Design & Systems** — 5 Skills
   - `core_loop_design` — Core Loop Design
   - `mechanics_rules` — Mechanics & Rules Design
   - `progression_balance` — Progression & Balancing
   - `game_economy` — Game Economy Design
   - `player_experience` — Player Experience & Retention Design
3. **Software Architecture & Programming** — 5 Skills
   - `system_architecture` — Game Software Architecture
   - `code_quality` — Code Quality & Refactoring
   - `data_save_systems` — Data, Save & Serialization
   - `gameplay_frameworks` — Gameplay Frameworks & Patterns
   - `debugging_code` — Programming Diagnostics
4. **Godot Engine** — 5 Skills
   - `godot_project_setup` — Godot Project Setup
   - `godot_gdscript` — GDScript Engineering
   - `godot_scenes_nodes` — Scenes, Nodes & Signals
   - `godot_render_physics` — Godot Rendering & Physics
   - `godot_export_plugins` — Godot Plugins & Export
5. **Unity Engine** — 5 Skills
   - `unity_project_arch` — Unity Project Architecture
   - `unity_csharp` — Unity C# Engineering
   - `unity_gameplay` — Unity Gameplay & Input
   - `unity_rendering` — Unity Rendering & Performance
   - `unity_builds` — Unity Build & Packages
6. **Unreal Engine** — 5 Skills
   - `unreal_blueprints` — Blueprint Engineering
   - `unreal_cpp` — Unreal C++ Engineering
   - `unreal_gameplay_framework` — Unreal Gameplay Framework
   - `unreal_materials_world` — Unreal Materials & World
   - `unreal_build_debug` — Unreal Build & Debugging
7. **2D Art & Animation Assets** — 5 Skills
   - `2d_visual_direction` — 2D Visual Direction
   - `sprite_pixel_art` — Sprites & Pixel Art
   - `tilesets_backgrounds` — Tilesets & Backgrounds
   - `2d_vfx` — 2D Visual Effects
   - `2d_asset_pipeline` — 2D Asset Pipeline
8. **3D Art & Environments** — 5 Skills
   - `3d_modeling` — 3D Modeling
   - `materials_textures` — Materials & Texturing
   - `environment_art` — Environment Art & Modular Kits
   - `lighting_rendering` — Lighting & Rendering Art
   - `3d_asset_optimization` — 3D Asset Optimization
9. **Animation & Rigging** — 5 Skills
   - `character_rigging` — Character Rigging
   - `character_animation` — Character Animation
   - `animation_state_machines` — Animation State Machines
   - `motion_capture_retarget` — Motion Capture & Retargeting
   - `cinematic_animation` — Cinematics & Sequencer Animation
10. **Game AI & NPC Systems** — 5 Skills
   - `npc_behavior` — NPC Behavior Architecture
   - `navigation_pathfinding` — Navigation & Pathfinding
   - `enemy_combat_ai` — Enemy & Tactical AI
   - `crowd_simulation` — Crowd & Population Simulation
   - `ai_debug_tools` — AI Debugging & Evaluation
11. **Physics & Simulation** — 5 Skills
   - `rigid_body_collision` — Rigid Bodies & Collision
   - `character_physics` — Character Movement Physics
   - `vehicle_physics` — Vehicle Physics Foundations
   - `advanced_simulation` — Advanced Physical Simulation
   - `physics_validation` — Physics Stability & Testing
12. **Gameplay, Controls & Camera** — 5 Skills
   - `input_architecture` — Input Architecture
   - `touch_controls` — Touch & Mobile Controls
   - `game_feel` — Game Feel & Feedback
   - `camera_systems` — Camera Systems
   - `accessibility_controls` — Control Accessibility
13. **Multiplayer & Networking** — 5 Skills
   - `network_architecture` — Network Architecture
   - `replication_sync` — Replication & Synchronization
   - `matchmaking_sessions` — Matchmaking & Sessions
   - `netcode_prediction` — Latency, Prediction & Reconciliation
   - `multiplayer_security` — Multiplayer Security & Anti-cheat
14. **Narrative & Worldbuilding** — 5 Skills
   - `story_structure` — Story Structure & Plot
   - `character_design` — Character & Faction Design
   - `dialogue_writing` — Dialogue & Branching Conversations
   - `quests_missions` — Quest & Mission Design
   - `cinematic_direction` — Cinematic & Narrative Direction
15. **Audio & Music** — 5 Skills
   - `sound_design` — Sound Design
   - `adaptive_music` — Adaptive Music
   - `voice_pipeline` — Voice & Dialogue Audio Pipeline
   - `spatial_audio` — Spatial & Environmental Audio
   - `audio_implementation` — Interactive Audio Implementation
16. **UI/UX & Interface** — 5 Skills
   - `ux_flows` — UX Flows & Information Architecture
   - `hud_design` — HUD & In-game Interface
   - `menus_settings` — Menus, Settings & Options
   - `ui_implementation` — UI Implementation & Architecture
   - `ui_accessibility` — UI Accessibility & Readability
17. **Performance & Cross-platform** — 5 Skills
   - `profiling_cpu_gpu` — CPU/GPU Profiling
   - `memory_loading` — Memory & Loading Optimization
   - `mobile_optimization` — Mobile Performance Optimization
   - `platform_compatibility` — Platform Compatibility
   - `scalability_settings` — Scalable Quality Settings
18. **QA, Testing & Debugging** — 5 Skills
   - `test_strategy` — Test Strategy & Acceptance Criteria
   - `bug_triage` — Bug Reproduction & Triage
   - `automated_testing` — Automated & Regression Testing
   - `playtesting` — Playtesting & Usability Testing
   - `release_qa` — Release QA & Compatibility
19. **Git & Collaboration** — 5 Skills
   - `git_workflow` — Git Branching & Workflow
   - `github_projects` — GitHub Issues & Projects
   - `code_review` — Code Review & Pull Requests
   - `asset_versioning` — Large Asset & Binary Versioning
   - `release_versioning` — Versioning & Change Logs
20. **Build, Publishing & Maintenance** — 5 Skills
   - `build_pipeline` — Build & Export Pipeline
   - `android_release` — Android Packaging & Release
   - `desktop_console_release` — Desktop & Console Release
   - `store_compliance` — Store Submission & Compliance
   - `postlaunch_maintenance` — Post-launch Maintenance
21. **Level Design & World Building** — 5 Skills
   - `level_blockout` — Level Blockout & Greyboxing
   - `world_layout` — World Layout & Navigation
   - `encounter_design` — Encounter & Combat Space Design
   - `environment_storytelling` — Environmental Storytelling
   - `open_world_streaming` — Open World & World Streaming
22. **Combat & Action Systems** — 5 Skills
   - `combat_mechanics` — Combat Mechanics
   - `melee_combat` — Melee Combat Systems
   - `ranged_combat` — Ranged Combat Systems
   - `boss_design` — Boss & Elite Encounter Design
   - `combat_balance` — Combat Balance & Damage Models
23. **Vehicles & Racing Games** — 5 Skills
   - `vehicle_handling` — Vehicle Handling & Feel
   - `racing_ai` — Racing AI & Opponents
   - `race_rules` — Race Rules & Event Systems
   - `vehicle_customization` — Vehicle Customization
   - `vehicle_camera_audio` — Vehicle Camera & Audio
24. **Sports Games & Simulation** — 5 Skills
   - `sports_rules` — Sports Rules & Match Logic
   - `sports_player_ai` — Sports Player AI & Team Tactics
   - `sports_ball_physics` — Ball & Sports Object Physics
   - `sports_animation` — Sports Animation & Motion
   - `sports_career` — Sports Career & Competition Modes
25. **RPG, Inventory & Progression** — 5 Skills
   - `rpg_character_builds` — Character Builds & Attributes
   - `inventory_equipment` — Inventory & Equipment Systems
   - `quests_progression` — RPG Quests & Progression
   - `loot_crafting` — Loot, Crafting & Rewards
   - `rpg_dialogue_choices` — RPG Choices & Consequences
26. **Procedural Generation & Tools** — 5 Skills
   - `procedural_worlds` — Procedural World Generation
   - `procedural_content` — Procedural Content Generation
   - `randomness_seed` — Randomness & Seed Management
   - `procedural_validation` — Procedural Content Validation
   - `editor_tools` — In-engine Editor & Creation Tools
27. **DCC Tools & Production Automation** — 5 Skills
   - `blender_pipeline` — Blender Production Pipeline
   - `asset_import_automation` — Asset Import Automation
   - `batch_content_tools` — Batch Processing & Content Tools
   - `build_automation` — Build Automation & CI
   - `documentation_automation` — Documentation & Project Tooling
28. **Backend, Cloud & Services** — 5 Skills
   - `backend_architecture` — Backend Architecture
   - `database_design` — Database & Data Modeling
   - `authentication_accounts` — Authentication & Player Accounts
   - `cloud_saves` — Cloud Saves & Synchronization
   - `live_services` — Live Services & Observability
29. **Monetization & Live Operations** — 5 Skills
   - `business_model` — Business Model & Pricing
   - `in_game_store` — In-game Store & Virtual Goods
   - `battle_pass_rewards` — Seasonal Progression & Reward Tracks
   - `live_events` — Live Events & Content Operations
   - `ethical_monetization` — Ethical Monetization & Compliance
30. **Accessibility & Localization** — 5 Skills
   - `accessibility_audit` — Accessibility Audit
   - `color_visual_access` — Visual & Color Accessibility
   - `subtitles_audio_access` — Subtitles & Hearing Accessibility
   - `localization_pipeline` — Localization Pipeline
   - `cultural_review` — Culturalization & Regional Review
31. **Security, Privacy & Trust** — 5 Skills
   - `secure_game_design` — Secure Game Design
   - `client_data_security` — Client Data & Secret Management
   - `account_privacy` — Privacy & Player Data
   - `moderation_safety` — Player Safety & Moderation
   - `dependency_audit` — Dependency & Supply Chain Audit

## Packs fournis
- `CGS_SKILLS_155_INDIVIDUELS.zip` : archive contenant les 155 ZIP individuels.
- `CGS_SKILLS_31_DOMAINES.zip` : archive contenant 31 ZIP, un par domaine, chacun avec cinq Skills.
- `CGS_GAME_STUDIO_UNIVERSAL_SKILLS_V2.zip` : bibliothèque complète en dossiers, avec tous les `SKILL.md` et ce guide.

## Importation dans Claude
1. Extraire l'archive des Skills individuels ou des domaines.
2. Dans Claude Web, ouvrir Customize / Personnaliser puis Skills.
3. Utiliser l'option d'importation de Skill si elle est proposée.
4. Importer les ZIP individuels. Si l'interface accepte un ZIP par domaine, importer les archives de domaines.
5. Activer les Skills nécessaires au projet.

## Utilisation économique des tokens
- Ne pas charger les 155 Skills dans chaque demande.
- Pour une tâche courante, utiliser 1 Skill de direction si nécessaire et 1 à 3 Skills techniques pertinents.
- Garder un fichier `PROJECT_CONTEXT.md` court par projet : moteur/version, cible, architecture, état, bugs connus et prochaine tâche.
- Réutiliser les Skills génériques et créer un Skill spécialisé uniquement lorsqu'un besoin récurrent le justifie.

## Limites et transparence
Les Skills sont des instructions réutilisables, pas des connecteurs ni des logiciels. Ils ne donnent pas à Claude un accès automatique à Godot, Unity, Unreal, Blender, un appareil Android/iPad, GitHub ou un terminal. Les actions concrètes dépendent des outils et autorisations disponibles dans la session. Les exports et tests doivent être exécutés dans un environnement compatible.

## Convention d'évolution
Versionner les Skills, conserver un historique des changements, tester chaque nouvelle version sur un petit cas réel et éviter les doublons. Ajouter un sixième Skill à un domaine seulement si sa responsabilité est distincte ; sinon créer un nouveau domaine.