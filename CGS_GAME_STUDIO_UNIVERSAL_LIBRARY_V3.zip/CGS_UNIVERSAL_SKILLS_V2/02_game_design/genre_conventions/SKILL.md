---
name: Genre Conventions & Innovation
description: Analyse les conventions d'un genre et identifie des innovations pertinentes.
---

# Genre Conventions & Innovation

## Mission
Analyse les conventions d'un genre et identifie des innovations pertinentes.

## Méthode
1. Confirmer le contexte, le moteur et sa version, la plateforme et les contraintes du projet.
2. Inspecter les fichiers, conventions, dépendances et ressources existantes avant toute modification.
3. Définir une solution adaptée, ses risques, ses prérequis et ses critères d'acceptation.
4. Produire un résultat concret, modulaire et documenté.
5. Vérifier avec les outils réellement disponibles et rapporter exactement les tests effectués.

## Exigences
- Ne pas inventer d'API, de fichier, de test ou de résultat.
- Préserver le travail existant et éviter les refactorisations non nécessaires.
- Prévoir les cas limites, erreurs, performances et accessibilité pertinents.
- Respecter sécurité, confidentialité, licences et règles des plateformes.
- Si un outil manque, fournir une procédure réaliste plutôt que prétendre avoir exécuté l'action.

## Livrable
Fournir les changements ou fichiers nécessaires, les décisions importantes, les vérifications réellement réalisées et les limites restantes.
